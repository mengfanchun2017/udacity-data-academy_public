# 00 SQL课程简介

[TOC]

## / SQL课程内容

> **<center> SQL </center>**
> 
> ---
> **SQL初级：**
> - [**/数据分析与SQL/** Lesson1 基本](https://classroom.udacity.com/nanodegrees/nd002-cn-svip/parts/013c1cc3-2dfa-4abb-8213-93aba5118ebe/modules/633ca2b0-b1b2-4821-89f8-60584b2a4a54/lessons/614cf95a-13bf-406c-b092-e757178e633b/concepts/9f672e93-fdcd-4332-a6ef-41edcf8416f1)
> - [**/数据分析与SQL/** Lesson2 SQL JOIN](https://classroom.udacity.com/nanodegrees/nd002-cn-svip/parts/013c1cc3-2dfa-4abb-8213-93aba5118ebe/modules/633ca2b0-b1b2-4821-89f8-60584b2a4a54/lessons/8f23fc69-7c88-4a94-97a4-d5f6ef51cf7b/concepts/192237ba-14c1-460c-ac69-ab455741cdc2)
> - [**/数据分析与SQL/** Lesson3 SQL 聚合](https://classroom.udacity.com/nanodegrees/nd002-cn-svip/parts/013c1cc3-2dfa-4abb-8213-93aba5118ebe/modules/633ca2b0-b1b2-4821-89f8-60584b2a4a54/lessons/76a484da-1f2e-4886-ba2c-684bb30e267d/concepts/283d9eba-2541-47ab-8111-6dd57ff3f066)
> - [**/数据分析与SQL/** Lesson4 SQL 子查询和临时表格](https://classroom.udacity.com/nanodegrees/nd002-cn-svip/parts/013c1cc3-2dfa-4abb-8213-93aba5118ebe/modules/633ca2b0-b1b2-4821-89f8-60584b2a4a54/lessons/b50a9cfd-566a-4b42-bf4f-70081b557c0b/concepts/b53dc474-19a9-4969-8fdf-5d1f164b18ff)
> 
> **SQL进阶：**
> - [**/数据分析与SQL/** Lesson5 SQL 数据清理](https://classroom.udacity.com/nanodegrees/nd002-cn-svip/parts/013c1cc3-2dfa-4abb-8213-93aba5118ebe/modules/539eaeaa-f269-46f9-b040-4bf88bebdbe7/lessons/03f64082-fa4d-4aff-80be-d48597867e07/concepts/d529924c-52ba-4a54-821d-549ba998272a)
> - [**/数据分析与SQL/** Lesson6 (选修) SQL 窗口函数](https://classroom.udacity.com/nanodegrees/nd002-cn-svip/parts/013c1cc3-2dfa-4abb-8213-93aba5118ebe/modules/539eaeaa-f269-46f9-b040-4bf88bebdbe7/lessons/a717e896-d9da-404c-8963-ae690279f2df/concepts/209ab8f1-1802-46ce-906b-f03e61fa4c90)
> - [**/数据分析与SQL/** Lesson7 (选修) SQL高级并集与性能优化](https://classroom.udacity.com/nanodegrees/nd002-cn-svip/parts/013c1cc3-2dfa-4abb-8213-93aba5118ebe/modules/539eaeaa-f269-46f9-b040-4bf88bebdbe7/lessons/79e079c3-42c0-4413-843a-ddf3a261d1cf/concepts/69b2120c-7bac-46db-9716-0056888c6b2b)
> 
> **SQL项目：**
> - [**/数据分析与SQL/** Project（基于零售数据挖掘业务特征）](https://classroom.udacity.com/nanodegrees/nd002-cn-svip/parts/013c1cc3-2dfa-4abb-8213-93aba5118ebe/modules/b75f3bca-2a1c-4c73-87fd-27ed33bb0921/lessons/94778dd8-ced4-4310-bde6-6d7141a348fb/concepts/799dc34c-b61b-4506-a606-957e91d591b3)

## / 什么是SQL

我们来看看wiki对SQL的定义：
> SQL是一种特定目的编程语言，用于管理关系数据库管理系统（RDBMS），或在关系流数据管理系统（RDSMS）中进行流处理。[/原文链接/](https://zh.wikipedia.org/wiki/SQL)

SQL就是Structure Query Language的缩写，是用来查询和操作的数据的一种语言（课程中的定义式：a language used to interact with a database），看起来是这个样子滴：

![-c](media/15447481264021/15463045758687.jpg)

是本课程中接触的第一种编程语言（大多数人认为SQL是一个编程语言，但是很多人因为其缺乏完整性而提出了异议，SQL虽然没有类和循环，但其仍然有算术表达式、函数和变量。因为只是面向数据库，也有说SQL是领域编程语言的）。课程中将会通过入门、高级、项目3个部分帮我们掌握SQL，加油！

## / 完成课程的环境

课程中的练习在线完成即可，但在完成项目时需要我们自己搭建SQL环境。课程中对于环境有详细的说明：[/SQL环境说明/](https://classroom.udacity.com/nanodegrees/nd002-cn-svip/parts/013c1cc3-2dfa-4abb-8213-93aba5118ebe/modules/b75f3bca-2a1c-4c73-87fd-27ed33bb0921/lessons/94778dd8-ced4-4310-bde6-6d7141a348fb/concepts/799dc34c-b61b-4506-a606-957e91d591b3#)建议如下：

- 下载 DB Browser for SQLite。对于不同类型的数据库，可以使用的数据库浏览器也有很多。在本课程中，我们将使用 DB Browser for SQLite。当然了，你也可能使用其他类似的浏览工具。[/下载/](http://sqlitebrowser.org/)
- 在项目时下载数据库，如果项目文件打不开，我在weiyun中有搬砖。
- 将 Browser 与数据库连接起来
    - 打开 DB Browser to SQLite
    - 点击 Open Database
    - 导航到 Northwind.sqlite3 文件
    - 点击 Execute SQL
    - 开始查询数据

## / SQL项目

[/基于零售业数据进行信息挖掘/](https://classroom.udacity.com/nanodegrees/nd002-cn-svip/parts/013c1cc3-2dfa-4abb-8213-93aba5118ebe/modules/b75f3bca-2a1c-4c73-87fd-27ed33bb0921/lessons/94778dd8-ced4-4310-bde6-6d7141a348fb/concepts/799dc34c-b61b-4506-a606-957e91d591b3)
![-c](media/15447481264021/15447485385274.jpg)