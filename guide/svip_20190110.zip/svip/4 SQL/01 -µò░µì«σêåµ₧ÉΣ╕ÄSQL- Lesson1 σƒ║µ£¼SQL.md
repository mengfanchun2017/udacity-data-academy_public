# 01 /数据分析与SQL/ Lesson1 基本SQL

[TOC]

## / 4.ERD基础知识
在课程的最开始，介绍了ERD - Entity Relationship Diagram / 实体关系图。（了解）大家注意其中有PK和FK，其实这是对右侧column的限制（比如说所有id都是PK，是Primary Key，说明这个列是主键，几种column的标识如下：

- 主键约束 SQL中constraint PK_字段 primary key(字段),
- 唯一约束 constraint UK_字段 unique key(字段),
- 默认约束 constrint DF_字段 default('默认值') for 字段,
- 检查约束 constraint CK_字段 check(约束。如：len(字段)>1),
- 主外键关系 constraint FK_主表_从表 foreign(外键字段) references 主表(主表主键字段)

![ERD-c800](media/15428134747968/week1_erd_SQL.jpg)

## / 7.视频：数据库如何存储数据

这一节从 Excel 电子表格出发对 SQL 数据库做了解释：
1. **数据库中的数据存储在类似于 Excel 电子表格的表中。**  
大多数情况下，可以将数据库视为一堆 Excel 电子表格。每个电子表格都有行和列。每行保存有关交易、个人、公司等的数据。而每列所保存的数据与你关心的某一特定行相关，如名称、位置、唯一身份等。  
2. **同一列中的所有数据必须符合数据类型。**  
将整个列认为是定量离散的或是某种字符串。这说明如果特定列中有一行字符串，那么整个列可能会更改为文本数据类型。 **如果想使用此列进行数学计算，这可能会非常糟糕！**   
3. **列类型一致是快速使用数据库的主要原因之一**。   
数据库通常会存储**海量**数据。因此，知道这些列都是相同类型的数据意味着可快速从数据库获取数据。

## / 8.文本+练习：数据库类型

需要注意，在课程内嵌的环境和课程中，使用的是PostgreSQL。大部分是通用的，但是也会有小的区别，如下链接介绍：[/三种最常见的SQL类型区别/](https://www.digitalocean.com/community/tutorials/sqlite-vs-mysql-vs-postgresql-a-comparison-of-relational-database-management-systems) 

## / 9.视频语句类型

Plus：一段SQL语句是Statements，由clauses组成(SELECT、FROM可以简单的理解一个大写的是一个clauses，很多clauses组成了Statements)。

## / 24.视频：WHERE

使用WHERE时，后面的运算符有两种。第一种是表示大小判断的算术运算符，第二种是可以用于进行文本之间判断的逻辑运算符，逻辑运算符包括：

- LIKE 表示符合通配符规则的都选出来。其中%表示其他可能的数字。
- IN 表示按照后面的值精确匹配（比如过滤出特定顾客的订单），可以是（x，y）这样的多值。
    
```sql
WHERE name LIKE '%one%';
WHERE channel IN ('organic', 'adwords');
```
## / PLUS 派生列

Derived Column。我们将现有的列组合，生成的新列称为派生列。在生成以后，可以用AS为这列起名（否则筛选出的结果这列名字是？Column这样的）.

```sql
SELECT standard_qty / (standard_qty + gloss_qty + poster_qty) AS stand_ratio
```

## / PLUS SQL语句的顺序

SQL语句的顺序是：SFWOL（每行缩写）

```sql
SELECT col1, col2
FROM table1
WHERE col3  > 5 AND col4 LIKE '%os%'
ORDER BY col5
LIMIT 10;
```

## / Plus SQL语句为什么要大写

其实Select、 SELECT、 SeleCT这样都是能正常运行的。但是大家想过没有，为什么都可以运行？因为SQL语句在执行的时候会先把语句都转换成大写的。如果写了小写的，会在执行时候先进行转换。增加执行的时间，当语句很多的时候影响执行效率。一般大公司会对此做要求。而且在很长代码的时候大写更容易辨认。

## / Plus SQL中的单引号和双引号

SQL环境中使用单引号和双引号都是可以的。但如果环境中启用了NSI_QUOTES的话就回出现错误，所以建议统一使用单引号。

## / Plus Join的类别

在SQL的选修课程中讲了Join，大家可以参考下面这个图方便理解：

![week1-Join-SQ-c](media/15428134747968/week1-Join-SQL.jpg)


如果学完了课程，也可看这个SQlite的Join做复习：[/SQLiteJohn/](http://www.runoob.com/sqlite/sqlite-joins.html)

## / Plus 联合主键

在SQL中，还有一种联合主键：
联合主键就是用2个或2个以上的字段组成主键。
用这个主键包含的字段作为主键，这个组合在数据表中是唯一，且加了主键索引。 比如你的订单表里有很多字段，一般情况只要有个订单号bill_no做主键就可以了，但是现在要求可能会有补充订单，使用相同的订单号，那么这时单独使用订单号就不可以了，因为会有重复。那么你可以再使用个订单序列号bill_seq来 作为区别。把bill_no和bill_seq设成联合主键。
[/原文链接/](http://www.cnblogs.com/UniqueColor/p/7234340.html)

ps:课程中有一道题是说主键是否只有一列，可以按照是做回答。（可以理解为主键唯一，所以是一列。如果需要使用联合主键，则联合主键是多列。）

## / Plus 数据库的一致性

本节中提到了SQL之所以能够高效的处理数据库中的数据，是因为数据库的列都是同一类别的数据（也叫Feature）。对于数据库做一点扩展：数据一致性就是数据保持一致，在分布式系统中，可以理解为多个节点中数据的值是一致的。

- 强一致性：当更新操作完成之后，任何多个后续进程或者线程的访问都会返回最新的更新过的值。这种是对用户最友好的，就是用户上一次写什么，下一次就保证能读到什么。根据 CAP 理论，这种实现需要牺牲可用性。
- 弱一致性：系统并不保证续进程或者线程的访问都会返回最新的更新过的值。系统在数据写入成功之后，不承诺立即可以读到最新写入的值，也不会具体的承诺多久之后可以读到。
- 最终一致性：弱一致性的特定形式。系统保证在没有后续更新的前提下，系统最终返回上一次更新操作的值。在没有故障发生的前提下，不一致窗口的时间主要受通信延迟，系统负载和复制副本的个数影响。DNS 是一个典型的最终一致性系统。
- 其实一致性是缘由CAP定理：一致性（Consistency）、可用性（Availability）和分区耐受性（Partition tolerance），3个属性只可能同时满足2个.

## / Plus 配置自己的SQL环境

- SQL是Structured Query Language的缩写，是人与关系型数据库交互的通用语言。
- 不同的关系型数据库的代码会有一些区别。
- sqllite是一个轻量化的关系型数据库，下载后，在命令行调用就可以进入（和Uda的工作空间相同了），下载地址：https://sqlite.org/download.html
- python和数据库。有很多操作数据库的接口，比如sqlite3是用来操作sqlite库的。其实python一般不直接操作数据库，而是用一个orm框架作为中间层，用操作对象的方法来操作数据库，避免直接写sql语句，这样比较方便，也可以防止sql注入攻击。sqlalchemy是比较常用的orm，另外一些web框架也会提供自己的orm，比如django自带的就很好用[/廖雪峰的一篇orm介绍/](https://www.liaoxuefeng.com/wiki/001374738125095c955c1e6d8bb493182103fac9270762a000/0014021031294178f993c85204e4d1b81ab032070641ce5000)

## / Plus 移动平均数是干什么的

- 统计中的移动平均法则对动态数列的修匀的一种方法，是将动态数列的时距扩大。所不同 的是采用逐期推移简单的算术平均法，计算出扩大时距的各个平均是，这一些列的推移的序时平均数就形成了一个新的数列，通过移动平均，现象短期不规则变动的影响被消 除如果扩大的时距能与现象周期波动的时距相一致或为其倍数，就能进一步削弱季节变动和循环变动的影响，更好的反应现象发展的基本趋势。
- 就是说为了减小波动。比如像项目中这种看长时间每年平均气温的需求。或者大家可以想想股票如果补仓了，那么所持有的所有股票，的平均值就变化了，这平均值一般是下一步决策的依据。
- 移动平均（Moving Average，MA），是技术分析中一种分析时间序列数据，最简单、最常用的分析工具之一，如股价（如开盘价、收盘价、最高价、最低价）、回报或交易量等，抚平短期波动，反映长期趋势或周期，在变化无常的市场中能发挥特别的作用。移动平均线也是其它许多技术指标的基石。
- 可以参考：[/移动平均数简介/](http://www.cnblogs.com/liuning8023/p/3548770.html)

## / Plus 在 Jupyter Notebook 处理sql文件

如果想在python环境（比如说课程后面的 Jupyter Notebook）中处理 sqllite 数据也是可以的，导入sqlite3库即可：

```python
import sqlite3
import pandas as pd
cnx = sqlite3.connect('database.sqlite')
df = pd.read_sql_query("SELECT * FROM Player_Attributes", cnx)
# 彩蛋，复盘时候可以参考的kaggle的足球数据清理的一个例子：
# https://www.kaggle.com/dimarudov/data-analysis-using-sql
```