# 02 /描述统计/ Lesson2 描述统计学2

## / 1-12.什么是离散程度测量

Measures of Spread ： How far are points from one another
- 5数概括法：Min、Q1、Q2（mean均值）、Q3、最大值（.describe的输出就是这5个数）
- 极差 Range = Max - Min
- 四分卫差 Interquartile Range (IQR) = Q3 - Q1 (中间50%的数据区间）
- 标准差 Standard Deviation：On average, how much each point varies from the mean of the points（每个观测值与均值之差的平均值）标准差是方差的平方根
- 方差 Variance：Average squared difference of each observation from the mean 
- 几个概念的总结：https://classroom.udacity.com/nanodegrees/nd002-cn-basic-vip/parts/4e7e2f82-e05e-4fbe-b29c-fe3169c6dd77/modules/0596b9e8-4a3a-41c3-a929-6c72c0c93925/lessons/c5b785aa-a0e9-45ac-8c4f-6e192829babe/concepts/5f2d9388-2cdc-46d5-81f8-8293edaafdb4
- 使用标准差的好处是使用原始数据的单位（方差带平方运算，所以单位不同），意义是只用一个值就能体现离散程度。标准差经常用于评估金融风险，帮助确定药物在医学研究中的意义，以及测量预测类计算的结果误差，例如预测明天的降雨量或通勤时间。

## / 13.形状

Shape：How to use histograms to determine shape associated with data（就是从图形形状看出数据的分布情况）
- 直方图的形状
    - Right Skewed（右偏态）
    - Left Skewed（左偏态）
    - Symmetric（对称分布，一种是钟形曲线）

## / 20.21.形状与异常值

Outliers: Data points that fall very far from the rest of the values in our dataset（就是明显超出数据集范围的数据，比如年龄统计中有个人322岁，肯定是有问题。注意课程中的例子，扎克伯格的年薪是真实值，但是个异常值，因为他挣得太多了，平均起来没有任何意义）

![-c400](media/15428134749038/15438642616107.jpg)

这一节课程中有个超详细的outlier的识别文章：http://d-scholarship.pitt.edu/7948/1/Seo.pdf 简单的说，就是如果发现了Outliers，需要注意以下5点：

1. 注意到它们的存在以及对概括性度量的影响。
2. 如果有拼写错误 —— 删除或改正。
3. 了解它们为什么会存在，以及对我们要回答的关于异常值的问题的影响。
4. 当有异常值时，报告五数概括法的值通常能比均值和标准差等度量更好地体现异常值的存在。
5. 报告时要小心。知道如何提出正确的问题。

## / 27.描述统计与推论统计

统计可以分为两类：
- 描述统计：是用来描述收集的数据（就是对现有的数据分析后给出结论，各路ppt大神和excel大表哥们，常做的就是这种）。
- 推论统计：在于使用我们收集的数据对更大的总体数据得出结论（是对未来做预测）。

统计学中的4个基本术语：
- 总体 Polulation：我们想要研究的整个群体。
- 样本 Sample：总体的子集
- 统计量 Statistic：描述样本的数值摘要
- 参数 Parameter：描述总体的数值摘要

![-c500](media/15428134749038/15438642924277.jpg)

大家可以看上面这个图Uda调查有多少学员喝咖啡的例子。这个例子中前Sample和Statistic是描述统计的，这个例子的描述统计：从5000反馈中得出，73%的学生喝咖啡。而推论统计是使用这5000个回复的数据，得出所有Uda学员喝咖啡习惯的结论。就是通过总体、参数、统计量，得出对参数的推论。因为在现实世界，很少能得到总体（就是每一个）的数据，所以要想知道参数（总体的实际情况），就要使用样本和统计量进行推论了，所以叫推论统计。

在接下来的 课程3:录取案例分析，中对这两节的内容有个实例。在1到11节介绍的是录取案例背景和比率计算，非常友好。在第12节是在workspace中跑一下代码，得出比例的结论（代码的部分之前都接触过很多了，大家看下，run一下就可以得出结论了，看到自己水平的有木有，原来前3个项目没白受虐待啊！）

这课的一个要点是知道统计学的危险，因为当分组不同时（无意的或者为了达到某个结论），分析结果可能完全不同！举了一个辛普森悖论的例子，除了课程中的内容，可以参考这个资料（挺有意思的，有空可以看下，其实根源在基数不同）：https://baike.baidu.com/item/%E8%BE%9B%E6%99%AE%E6%A3%AE%E6%82%96%E8%AE%BA