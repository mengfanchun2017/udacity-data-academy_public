W02 Python基础 [项目：探索共享单车用户行为规律1/4]

[TOC]

# /学习地图/

同学们，在经过项目1的热身之后，本周开始，我们要进行第二个项目：探索共享单车用户行为规律的学习了。

![-c600](media/15438102312976/15438595233896.png)

## / 项目背景

- 项目说明:在此项目中，你将利用 Python 探索与以下三大美国城市的自行车共享系统相关的数据：芝加哥、纽约和华盛顿特区。你将编写代码导入数据，并通过计算描述性统计数据回答有趣的问题。你还将写一个脚本，该脚本会接受原始输入并在终端中创建交互式体验，以展现这些统计信息。
- 练习目标：数据分析过程、数据整理、探索和可视化
- 项目概述：请先看下这一页，对项目有个感触[/项目简介/](https://classroom.udacity.com/nanodegrees/nd002-cn-basic-vip/parts/0ad43cea-8e74-4486-911c-d1fae2f03c97/modules/134150b9-81b0-40d1-9c2c-bb288bb49d55/lessons/e5bef1dd-5031-45c3-aaf7-8536f6f3cf8a/concepts/8846274e-0239-4eef-8619-f9854a068ca8)

## / 项目路径

项目名称：探索共享单车用户行为规律
项目时间：4周
- **第1周：Python基础内容** - Python基础（数据类型和运算符、控制流、函数、脚本编写）
- 第2周：Python数据处理内容 - Python数据分析（Numpy、Pandas库）
- 第3周：完成项目 - 项目：探索美国共享单车数据
- 第4周：通过项目 - 修改项目、查缺补漏、整理笔记

## / 本周项目推进（选做）

如果时间可以的话也可以浏览下项目，先熟悉下项目文件，建议如下：
- 完成探索美国共享单车数据项目的1-3节内容
- 搭建本地anaconda环境（Python3版本，选做），并确保Spyder可以使用。Udacity的课程全程为大家提供了线上项目资源。如果想要在本地完成的话可以安装anaconda环境，并且使用里面自带的spyder完成。安装配置的内容请参考课程中的：[/Anaconda的和Jupyter Notebook安装配置说明/](https://classroom.udacity.com/nanodegrees/nd002-cn-basic-vip/parts/e566ad37-6119-4448-a6bc-7ade73ef3992)、[/Spyder的简单教程/](https://blog.csdn.net/LucyGill/article/details/78068985)（请安装py3版本）。
- 下载bikeshare-new-2.zip项目文件。如果教室里面不能下载，请下载：[/我搬的砖/](https://github.com/mengfanchun2017/DAND-Basic/blob/master/Project1/Project1Files/bikeshare-new-2.zip)

# /目标1/：数据类型和运算符（复习）
此处和试学项目的内容相同，是python的基础内容，大家可以略过有不熟悉的再回看。如果需要可以回看week0中的试学项目讲解内容。另外也可以完成后面扩展的一个小练习作为复习：[/选学小练习/](https://classroom.udacity.com/nanodegrees/nd002-cn-basic-vip/parts/37aa085f-a2c7-48ac-8070-f17f5be7f2dd/modules/f0fc5dc7-15a0-41ea-acae-66eb3b761ae1/lessons/a6927fc9-e963-4403-847d-0a79c8b16a46/concepts/7114184b-9319-4c67-8e8c-59b73bc49101#)

## */ 23.集合

[/小节链接/](https://classroom.udacity.com/nanodegrees/nd002-cn-basic-vip/parts/0ad43cea-8e74-4486-911c-d1fae2f03c97/modules/2ceb59e6-2fa6-4177-a8b8-b6130f45ac3f/lessons/ebd93cf2-9329-4415-9bc2-7281e2aa9e13/concepts/38fa80cd-03b6-4003-9f57-b4f055649f6a)这一节中有个知识是在set中踢出一个数据，因为set没有索引，所以使用pop踢出的不是最有一个，而是随机一个，代码中是这样的：(这里对pop加print是为了方便观察，而不是程序需要。程序内心独白：你们人类什么都要看，少加个print不行啊！）

![-c600](media/15438102312976/15438595932489.jpg)

# /目标2/：控制流（重点）
对于任何一种编程语言，控制流（循环）都是非常重要的。if条件语句、for……in循环、while循环是python控制流的核心，本节请认真学习。如果想加深理解，也可以再参考[扩展链接](https://python.swaroopch.com/control_flow.html)

## ***/ 条件和循环（1-16节）

### // 条件（1-7小节）

条件对应的是1-7小节，就是当if后面的描述成立的时候，程序要做blabla，这里课程中讲解和练习都挺丰富，请认真完成练习。

### // 按位与或，逻辑与或的区别（选学）

在Python中的与或分为按位与逻辑两种。
- 按位：严格比较前后的两个元素。
    * 按位与`&`
    * 按位或`|`
- 逻辑：对前后的可迭代的结构（比如列表）进行比较。
    * 逻辑与`and`
    * 逻辑或`or`
- 逻辑的方式适用更广，在逻辑和位都可使用时，结果一致。

看以下两个例子便于理解（#后面是结果）：

```python
## 对于布尔数
a = True
b = False
print (a & b)  # 输出False
print (a | b)  # 输出True
print (a and b)  # 输出False
print (a or b)  # 输出True

## 对于列表
a_list = [True, False, True]
b_list = [True, True, False]
print (a_list & b_list)  # error
print (a_list | b_list)  # error
print (a_list and b_list)  # 输出[True, True, False]
print (a_list or b_list)  # 输出[True, False, True]
```

而到了ndarray这种数据结构（numpy的结构），& 和 | 也是可以运用的（可以直接作用在ndarray上面，不会报错）。而numpy中特意提供了.logical_and, logical_or, logical_not的逻辑与或非方法。那么既然按位的 & 和 | 可以处理了，为什么ndarray还要提供logical的这3个方法呢？因为性能会更好一点，我们可以认为ndaary提供的方法做了优化（极小规模测试了下，大概有10%的改善），代码和说明如下：

```python
# 定义2维的ndarray（注意，经测试如果用True和False没有改善）
a3 = np.array([
    [1, 0, 1, 1, 1, 1, 0, 1],
    [1, 1, 0, 0, 1, 1, 0, 0],
    [0, 1, 0, 1, 0, 0, 1, 1],
    [1, 1, 1, 0, 1, 1, 0, 1],
    [1, 0, 1, 1, 1, 1, 1, 0],
    [0, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 1, 0, 0, 1, 1]])
b3 = np.array([
    [0, 0, 0, 1, 0, 0, 0, 1],
    [0, 1, 0, 1, 0, 0, 1, 1],
    [1, 1, 1, 0, 1, 1, 0, 1],
    [1, 0, 1, 1, 1, 1, 1, 0],
    [0, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 1, 1, 1, 1, 1, 0],
    [1, 1, 0, 0, 1, 0, 0, 0],
    [1, 1, 1, 0, 1, 0, 1, 1]])
    
# 定义两种方式的比较函数
def compare1s():
    return a3 & b3, a3 | b3

def compare1bs():
    return np.logical_and(a3, b3), np.logical_or(a3, b3)

# 使用timeit是重复的，因为cpu有占用，所以用repeat进行多次，取最小的
# 如果不用repeat可以直接使用timeit如下：
# t = timeit('compare1b()', 'from __main__ import compare1b', number=100000)
# timeit的中文参考：https://www.cnblogs.com/PrettyTom/p/6657984.html
# timeit官方文档：https://docs.python.org/3/library/timeit.html
t3 = min(repeat('compare1s()', 'from __main__ import compare1s', number=100000, repeat=10))
t4 = min(repeat('compare1bs()', 'from __main__ import compare1bs', number=100000, repeat=10))

print(t3, t4, t4 / t3)    
# logical_and官方文档：https://docs.scipy.org/doc/numpy-1.13.0/reference/generated/numpy.logical_and.html

### result：
### 0.3266788399996585 0.284688735002419 0.8714636521995627
```

从结果看出，logical_and的方式时间缩短到了87%。

### // 循环（8-16节）

Python的循环有两种，for循环和while循环。抓狂了？为什么有两种循环呢！！！

**for循环：**从名字上看for是遍历，常见的是结合in的判断：

```python
for i in list:
    pass
```

这个意思就是说，当i在list中的时候，blabla。那么既然是遍历，这个i就是从list里面第一个到最后一个，都run一遍，之后结束。所以for in的对象是一个可迭代的对象（不要晕看例子）：

```python
#先看一个列表的例子
list = ['I ', 'love ', 'python ', 666, '!']
for i in list:
    print(i, end = '')
    #end = ''的意思是结尾不换行    
#---输出如下---
I love python 666!
  
#再看一下字符串的例子
string = 'GOOD'
for i in string:
    print(i)
#---输出如下---    
G
O
O
D
  
#看到这里，大家就明白了列表和字符串都是可迭代对象，因为能够按照顺序从同到尾遍历一下。
```

**while循环：**那么while呢，就是当...时候，做...的意思。和for不同，只要while这行判断成立，就会一直做下去。

综上所述，for in 适合可迭代目标的循环，while适合不知道要循环多少次，每次需要判断状态的循环。两个的区别咱们来个对比做小结：

1. for loops：
    1. know number of iterations
    2. can end early via break
    3. uses a counter
    4. can rewrite using a while loop
2. while loops:
    1. unbounded number of iterations
    2. can end early via break
    3. can use a counter but must initialize before loop and increment it inside loop
    4. may not be able to rewrite using a for loop
3. 咱们来个计算阶乘的例子，两个循环代码如下：
      
```python
#for loop solution
n = 5
fact = 1
for i in range(2, n + 1):
    fact = fact * i
print(str(n) + ' factorial is ' + str(fact))
  
#while loop solution
n = 5
fact = 1
i = 2
#while要初始化i
while i <= n:
    fact = fact * i
    i = i + 1
    #在循环中要对i进行更新否则会进入死循环
print(str(n) + ' factorial is ' + str(fact))
  
#---输出是一样的---
5 factorial is 120
```

OK，大家看明白了么？for in 这种循环方式对于可迭代目标更加简洁（也能用enumerate再简化一点点，有兴趣的可以自行搜索）。但是其实两种都是OK的，是个人风格问题。

### // 控制流附加练习 (选学）

另外，在初级课程后面的python选学中有更多的控制流的例子和练习，如果时间允许的话也可以看看：[/python控制流附加/](https://classroom.udacity.com/nanodegrees/nd002-cn-basic-vip/parts/37aa085f-a2c7-48ac-8070-f17f5be7f2dd/modules/f0fc5dc7-15a0-41ea-acae-66eb3b761ae1/lessons/ee5eb8d0-dc89-4b42-8feb-9fbe35a5fecd/concepts/58b6ab9c-d283-4c00-bbe5-f8a518787088)

## **/ Zip和Enumerate以及列表推导式

### // Zip和Enumerate

我们先来说zip，就是拉链的意思，可以把进行组合和拆分，方便进行数据的处理。课程里的例子非常详细。其实zip函数可以进行行列转换，感兴趣的话：[参考链接](https://blog.csdn.net/shomy_liu/article/details/46968651)

Enumerate函数，其实就是简化for的一个内置函数，让你的循环更漂亮！

### // 列表推导式

列表推导式（List Comprehension）：可以把一个设定初始空值，用条件循环填充的循环，简化成一个赋值语句，对比以下，注意else语句的位置是在前面：

```python
#for loop:
capitalized_cities = []
for city in cities:
    capitalized_cities.append(city.title())
    
#list comprehension:
capitalized_cities = [city.title() for city in cities]

#list comprehension else:
squares = [x**2 if x % 2 == 0 else x + 3 for x in range(9)]
```

书中练习的解释（要先做完在看呦）：

```python
#练习1
names = ["Rick Sanchez", "Morty Smith", "Summer Smith", "Jerry Smith", "Beth Smith"]
first_names = [name.split()[0].lower() for name in names]
##此处split会把Rick Sanchez分解为Rick和Sanchez，通过[0]就是选定了Rick
print(first_names)
#['rick', 'morty', 'summer', 'jerry', 'beth']

#练习3
scores = {
             "Rick Sanchez": 70,
             "Morty Smith": 35,
             "Summer Smith": 82,
             "Jerry Smith": 23,
             "Beth Smith": 98
          }

passed = [name for name, score in scores.items() if score >= 65]
##scores.items()就是把最前面的scores字典拆分成index（人名，Rick Sanchez）和value（70），这样的话就赋值给前面的name，score
print(passed)

#输出
['Beth Smith', 'Summer Smith', 'Rick Sanchez']
```

# /目标3/：函数（重点）

## */ 5.变量作用域

如果遇到UnboundLocalError说明函数中对函数外定义的变量进行了修改。Python不允许函数修改不在函数作用域内的变量（这种方式也可以让不同函数中可以有一样的变量名）。这个原则仅适用于整数和字符串，列表、字典、集合、类中可以在子程序中（子函数）通过修改局部变量达到修改全局变量的目的。

咱们看个错误的例子，下面这段代码会报错，因为函数buy_eggs试图修改函数外的变量：

```python
egg_count = 0

def buy_eggs():
    egg_count += 12 # purchase a dozen eggs

buy_eggs()
```®®®

正确的代码应该是这个样儿滴：

```python
def buy_eggs(count):
    return count + 12  # purchase a dozen eggs
egg_count = 0
egg_count = buy_eggs(12)
```

## */ 8.文档

docstrings和代码没有任何关系，但是却非常的有用，这里我直接盗版小艾助教大大的论述：

python中的docstring有特别精辟的解释，盗版如下：

> 1. python有一个很牛逼的功能叫做自省 
> 2. 有很多的自省函数，比如help，dir，type，id等等
> 3. 就是为了在程序运行期间获取对象的信息 
> 4. 比如这个docstring，可以通过help来查看。你的代码是干什么用的，怎么用的，别人就很清楚了 
> 5. 记住一点，代码是写给机器运行的，但是是写给人看的。可维护性，可读性非常重要。否则同事会画圈圈诅咒你的哦 
> 6. 你想象一下，你在写代码的时候老是有人打断你，问你你写的这个函数怎么用，如果你写了docstring，就不会有这样的遭遇了。也不会有想要把同事掐死的冲动。 
> 7. 为了团结友爱世界和平，请为你的函数和类添加docstring 
> 8. 你可能有一点困惑就是，我已经写了注释，还要不要写docstring 
> 9. 不困惑了，为了防止同事找我 ，我决定把docstring 写得叼一点 
> 10. 而且有很多工具可以自动根据docstring生成文档，省时省力 
> 11. 注释不能通过help查看哦，别人要有你的源文件，还得搜到你的函数才能看到注释 

docstrings的显示有两种方法，注意这两种方式都不用知道函数要求的参数是什么：

```python
help(functions)
# help的方式在vscode会在terminal停住，建议用下面的方法
print(functions.__doc__)
```

## **/ 11.Lambda表达式

当一个简单函数只会使用一次的时候，可以使用匿名函数的方式进行表达。比如下面这个例子，double为赋值对象，涉及2个参数x，y（就是lambada 后面跟的），计算的时候吧两个参数乘积为结果（函数的内容就是冒号后面的东西）。

这里重点要讲下map()函数，map函数的作用就是根据函数，对指定的序列做计算。语法是这样的（注意先是要怎么处理数据的函数，后是要处理的数）：

```python
#map函数
map(function, iterable, ...)
```
    
当然这个function也是可以使用lambada一次完成的，两种方式对比如下：

```python
#使用函数
def square(x) :            
    return x ** 2
map(square, [1,2,3,4,5]) 
#使用lambada
map(lambda x: x ** 2, [1, 2, 3, 4, 5])
#两种方式的结果是相同的：
[1, 4, 9, 16, 25]
    
#注意map是可以有多个输入的
map(lambda x, y: x + y, [1, 3, 5, 7, 9], [2, 4, 6, 8, 10])
#结果为
[3, 7, 11, 15, 19]
```

接下来我们就能看懂教室里的例子了：

```python
numbers = [
          [34, 63, 88, 71, 29],
          [90, 78, 51, 27, 45],
          [63, 37, 85, 46, 22],
          [51, 22, 34, 11, 18]
          ]
#首先numbers是一个嵌套的列表，有4个元素，每个元素（每行）又包括4个元素   
    
averages = list(map(lambda x :sum(x)/len(x),numbers))
#此处的list是将map生成的4行平均数存为一个列表
#lambada的内容是：sum(num_list)/len(num_list)，用每个元素的加和除以每个元素内部的个数
#最后numbers是输入
```

filter函数和map类似，如果感兴趣可以看[/扩展内容/](http://www.runoob.com/python/python-func-filter.html)

## */ 14.迭代器和生成器（选学）
这部分逻辑有一点点复杂，时间允许的话可以多看几遍，也可以参考：[/这个链接/](https://www.zhihu.com/question/20829330)

## */ 函数附加练习（选学）

在课程最后的python选学中有一块‘分解程序’的内容，讲的是在编程的时候接到一个任务后怎样拆分并且分模块组织好函数。可以浏览下找找函数使用的感觉：[/python函数附加/](https://classroom.udacity.com/nanodegrees/nd002-cn-basic-vip/parts/37aa085f-a2c7-48ac-8070-f17f5be7f2dd/modules/f0fc5dc7-15a0-41ea-acae-66eb3b761ae1/lessons/ee5eb8d0-dc89-4b42-8feb-9fbe35a5fecd/concepts/06ee921c-2c03-4521-80da-f0b95b29ea78)

## */ 函数和方法的区别（超级选学）

- 函数调用直接是：fuc1(arg1,arg2...)
- 方法的调用时：data.methord1().methord2()...
- 方法能做到的事情和函数类似，重大区别是可以串接（上面例子的形式）
- 其实方法还分为bound和unbound两种，上面的方法例子是unbound的，系统会自动把.methord()之前的东西放到（）内处理。想要细究的话请：[/附加1/](https://segmentfault.com/a/1190000009157792),[/附加2/](https://blog.csdn.net/amoscn/article/details/77074403)。
# /目标4/：脚本编写

## ***/ 8.在脚本中接受原始输入

这里出现了个有点奇怪的print函数，就是上节讲到
    
```python
name = input("Enter your name: ")
print("Hello there, {}!".format(name.title()))
```

## **/ 格式化字符串

### // 课程中初次见面

有点奇怪啊，不就是让用户输入个名字，不是应该这样的么？

```python
name = input("Enter your name: ")
print("Hello there, ", name, "!")
```

对的，实际上输出是一样的，后面这个我们比较熟悉，把字符和变量串在一起输出。但是观察下上下对比，是不是上面的这个比较简单呢？这种新的方法叫做：**print格式化字符串。**大家对比观察一下，其实就是在print里面放了个{},并在后面加了个.format(name.title)。这个语句的意思是，打印到{}的时候，把后面这个.format()里的东西打印出来，name.title就是把输入的name的第一个字母改为大写。默认{} {} {}...会按照后面.format(a, b, c)来替换,但也可以指定。比如{0}指定的是a，{1}指定的是b，以此类推。举个例子就知道了：
    
```python
##format methord
print('---test1:---')
print('I am lucky to eat {} {} {} {}!'.format(4,'eggs', 1, 'spam'))
print('---test2:---')
print('I am lucky to eat {2} {1} {3} {0}!'.format(4,'eggs', 1, 'spam'))
print('---test3:(option)---')
print('I am lucky to eat {2:.2f} {1} {3} {0}!'.format(4,'eggs', 1, 'spam'))
print('---test4:(option)---')
print('I am lucky to eat {2:.2f} {1:#^20} {3} {0}!'.format(4,'eggs', 1, 'spam'))
```

输出是这样的：其中test3，4是更为复杂的应用，感兴趣的话看这两个链接：https://blog.csdn.net/i_chaoren/article/details/77922939
https://www.cnblogs.com/wilber2013/p/4641616.html
    
```
---test1:---
I am lucky to eat 4 eggs 1 spam!
---test2:---
I am lucky to eat 1 eggs spam 4!
---test3:(option)---
I am lucky to eat 1.00 eggs spam 4!
---test4:(option)---
I am lucky to eat 1.00 ########eggs######## spam 4!
```

### // print中输出变量的简单方法

print再扩展一点，如果看到这样的家伙 + variable + ，是一种在字符串中加变量的方法，其实和逗号分隔是等价的:

```python
print('hi ' + name + ' !')
print("hi " + name + " !")
print('hi', name, '!')
print("hi", name, "!")
#这4个的输出都是一样的：（注意下代码前后的空格是不一样的，所以前面的也会用到）
hi handsome !
```

需要处理复杂的就print（"xxx{}" .format()） (ps:还有一种写法是print("xx%zz" % ())大家知道就可以了）。详细的带入列表和字符串的方法：https://stackoverflow.com/questions/17153779/how-can-i-print-variable-and-string-on-same-line-in-python
       
这一节后面还有个eval是把用户输入的内容当作python代码处理。扩展下也可以这样使用，把str字符转化为相应的内容(>>>是输入的代码），大家注意a和b的type是不一样的：
    
```python
>>> a = "{1: 'a', 2: 'b'}"
>>> type(a)
<type 'str'>
 
>>> b = eval(a)
>>> print(b)
{1: 'a', 2: 'b'}
>>> type(b)
 <type 'dict'>
```

### // format中的对齐

（本部分和下部分参考了这个[/非常详细的format说明/](https://www.cnblogs.com/zyq-blog/p/5946905.html))

填充常跟对齐一起使用，^ 、<、>分别是居中、左对齐、右对齐，后面带宽度
:号后面带填充的字符，只能是一个字符，不指定的话默认是用空格填充
比如：

```python
In [15]: '{:>8}'.format('189')
Out[15]: '   189'
In [16]: '{:0>8}'.format('189')
Out[16]: '00000189'
In [17]: '{:a>8}'.format('189')
Out[17]: 'aaaaa189'
```

### // 精度常跟类型f一起使用

精度的设定：注意这里的format对象要是具体的，不能是ndarray或者dataframe这样的输出，这两个的现实方式再后面会讲解。

```python
In [44]: '{:.2f}'.format(321.33345)
Out[44]: '321.33'
# 其中.2表示长度为2的精度，f表示float类型
In [47]: '{:,}'.format(1234567890)
Out[47]: '1,234,567,890'
# 其中，是分隔符（为了看着方便）
```

其他进制的转换：主要就是进制了，b、d、o、x分别是二进制、十进制、八进制、十六进制。

```python
In [54]: '{:b}'.format(17)
Out[54]: '10001'
In [55]: '{:d}'.format(17)
Out[55]: '17'
In [56]: '{:o}'.format(17)
Out[56]: '21'
In [57]: '{:x}'.format(17)
Out[57]: '11'
```

### // format对于可迭代对象的处理方式

在项目中遇到需要对dataframe的元素输出（ndarray也是类似）时，当前版本报错：TypeError: unsupported format string passed to Series.__format__

原因是format不能处理这种输出，要想输出dataframe的内容，需要用循环依次输出，举个例子（需要项目数据，请参考，无法复现，后续补充）：
    
## **/ 13.处理错误
大家理解try、except、else、finally4个语句的执行条件就好了。
- try：这是 try 语句中的唯一必需子句。该块中的代码是 Python 在 try 语句中首先运行的代码。
- except：如果 Python 在运行 try 块时遇到异常，它将跳到处理该异常的 except 块。
- else：如果 Python 在运行 try 块时没有遇到异常，它将在运行 try 块后运行该块中的代码。
- finally：在 Python 离开此 try 语句之前，在任何情形下它都将运行此 finally 块中的代码，即使要结束程序，例如：如果 Python 在运行 except 或 else 块中的代码时遇到错误，在停止程序之前，依然会执行此finally 块。
- 对于/15/的例子做个简单的说明（以注释方式）：
    
```python
def create_groups(items, num_groups):
    #定义函数，2个输入items（多少个东西），分成num_groups(分成多少个组）
    try:
        size = len(items) // num_groups
    #上来是计算每组大小
    except ZeroDivisionError:
        print("WARNING: Returning empty list. Please use a nonzero number.")
        return []
    #但是当发生ZeroDivisionError时（除数为0的时候的错误），就显示错误并返回空值
    else:
        groups = []
        for i in range(0, len(items), size):
        #是说从0到items的最大数（就是len(items)这个的结果），按照size（在try语句中得出的每组大小）进行循环
            groups.append(items[i:i + size])
            #每一个循环，把当前的组存追加存放到groups里面
        return groups
    #如果没报错，就是按照上面这一段把每组都有什么写到groups里面
    finally:
        print("{} groups returned.".format(num_groups))
    #无论怎么处理的，都打印一行提示，使用的是格式化字符串的方式
    
print("Creating 6 groups...")
for group in create_groups(range(32), 6):
    print(list(group))
print("\nCreating 0 groups...")
for group in create_groups(range(32), 0):
    print(list(group))
```

输出是这样的：
    
```
Creating 6 groups...
6 groups returned.
[0, 1, 2, 3, 4]
[5, 6, 7, 8, 9]
[10, 11, 12, 13, 14]
[15, 16, 17, 18, 19]
[20, 21, 22, 23, 24]
[25, 26, 27, 28, 29]
[30, 31]

Creating 0 groups...
WARNING: Returning empty list. Please use a nonzero number.
0 groups returned.
```
    
因为函数输出的是一个嵌套的列表，所以要用上面的方式把列表的每一组元素显示出来，我们加一句print就能看明白了：
    
```python
print(create_groups(range(38),3))
```
    
输出是这样的：
    
```
3 groups returned.
[range(0, 12), range(12, 24), range(24, 36), range(36, 38)]
```

另外，即是except有报错输出，也是可以通except as的方式访问并输出的，这一块知道就行了。

注意append和write区别，和with的用法
- 追加文件是用f.append(),使用f.write()将会覆盖文件
- 为了避免忘记f.close()关闭一个文件，可以使用with的方式：

```python
with open('my_path/my_file.txt', 'r') as f:
    file_data = f.read()
#和下面的语句是一样的
f = open('my_path/my_file.txt', 'w')
file_data = f.read()
f.close()
```

## */ 18.读写文件

注意这个地方有个新的.split(',')方法，用处是把line里面的内容用，split开，关于readline相关的用法，总结为以下几个例子：

```python
print('{0:-^30}'.format('print read'))
#print函数会在结尾自动加入换行
with open('print.format.py') as song:
    print(song.read(1))
    print(song.read(8))
    print(song.read(8))
    #print(song.read())

print('{0:-^30}'.format('print read end none'))
with open('print.format.py') as song:
    print(song.read(1), end = '')
    print(song.read(8), end = '')
    print(song.read(8))
    #print(song.read())

print('{0:-^30}'.format('print readline'))
with open('print.format.py') as song:
    print(song.readline())
    print(song.readline())
    print(song.readline(1), end = '\n\n')
    #可以看出readlline()是每次读取一行（/n换行跟随上一行，不会算成下一行）
    #如果readline(x),就是读出这行的x个字符
    #这种方式时结尾的/n不会打印
    #结尾\n\n 才会换行，一个的话会追加到x个字符后面

print('{0:-^30}'.format('print readlines'))
with open('print.format.py') as song:
    print(song.readlines(), end = '\n\n')
    #readlines是把所有行读入到一个列表中

print('{0:-^30}'.format('for line in file'))
test_lines = []
with open('print.format.py') as song:
#line可以替换成i，只不过line比较明确
#这里重点是，对于open的文件，for 循环是每次循环一行
    for line in song:
        test_lines.append(line.strip())
    print(test_lines,end = '\n\n')

print('{0:-^30}'.format('split lines'))
def create_cast_list(filename):
    cast_list = []
    #use with to open the file filename
    with open("circus.csv") as f:
        for line in f:
            name=line.split(',')[0]
            cast_list.append(name.strip())
        #下面的是最后一个循环的输出，输出做对比就明白很多了：
        print('{0:-^30}'.format('under is split testing'))
        print('originial: {0:#^20}'.format(line), end = '')
        nameall = line.split(',')
        nameallfirst = line.split(',')[0]
        print(name)
        print(nameall)
        print(nameallfirst)
    #use the for loop syntax to process each line
    #and add the actor name to cast_list

    return cast_list

cast_list = create_cast_list('circus.csv')
for actor in cast_list:
    print(actor)
```

结果如下，感兴趣的可以自己研究下：

```
----------print read----------
#
#format 
methord

-----print read end none------
##format methord

--------print readline--------
##format methord

print('---test1:---')

p

-------print readlines--------
['##format methord\n', "print('---test1:---')\n", "print('I am lucky to eat {} {} {} {}!'.format(4,'eggs', 1, 'spam'))\n", '\n', "print('---test2:---')\n", "print('I am lucky to eat {2} {1} {3} {0}!'.format(4,'eggs', 1, 'spam'))\n", '\n', "print('---test3:(option)---')\n", "print('I am lucky to eat {2:.2f} {1} {3} {0}!'.format(4,'eggs', 1, 'spam'))\n", '\n', "print('---test4:(option)---')\n", "print('I am lucky to eat {2:.2f} {1:#^20} {3} {0}!'.format(4,'eggs', 1, 'spam'))\n"]

-------for line in file-------
['##format methord', "print('---test1:---')", "print('I am lucky to eat {} {} {} {}!'.format(4,'eggs', 1, 'spam'))", '', "print('---test2:---')", "print('I am lucky to eat {2} {1} {3} {0}!'.format(4,'eggs', 1, 'spam'))", '', "print('---test3:(option)---')", "print('I am lucky to eat {2:.2f} {1} {3} {0}!'.format(4,'eggs', 1, 'spam'))", '', "print('---test4:(option)---')", "print('I am lucky to eat {2:.2f} {1:#^20} {3} {0}!'.format(4,'eggs', 1, 'spam'))"]

---------split lines----------
----under is split testing----
originial: The Fred Tomlinson Singers,  Amantillado Chorus / ... (7 episodes, 1969-1973)
The Fred Tomlinson Singers
['The Fred Tomlinson Singers', '  Amantillado Chorus / ... (7 episodes', ' 1969-1973)\n']
The Fred Tomlinson Singers
Graham Chapman
Eric Idle
Terry Jones
Michael Palin
Terry Gilliam
John Cleese
Carol Cleveland
Ian Davidson
John Hughman
The Fred Tomlinson Singers
```

## */ 20.导入本地模块
接下来讲解下if main这一块：
- if __name__ == '__main__' 简单的理解就是： 如果模块是被直接运行的，则代码块被运行，如果模块是被导入的，则代码块不被运行
- 是为了在导入时候不运行（被调用才运行）的限制
- 详细说明：http://blog.konghy.cn/2017/04/24/python-entry-program/
- /23标准库/
- 这里介绍了random标准库的两个用法，总结如下：

```python
import random
word_list = ['tatoo', 'happy', 'apple', 'ios', 4]

def generate_password():
    return str(random.choice(word_list)) + str(random.choice(word_list)) + str(random.choice(word_list))
    #增加了str确保如果wordlist里面有4这样的数字可以转化为字符
print(generate_password())

def generate_password2():
    return ''.join(random.sample(word_list,5))
    #join方式就不能加str，要求wordlist都是字符，但是既然是wordlist就应该都保证是字符
    #而不是在写处理代码时候再额外处理不推进str的方式
print(generate_password2())
```

## */ 26.第三方库
在安装python或者ananconda后，可以使用：`pip install package_name` 来安装需要的包。推荐的一些安装包很实用，[/链接归档/](https://classroom.udacity.com/nanodegrees/nd002-cn-basic-vip/parts/0ad43cea-8e74-4486-911c-d1fae2f03c97/modules/2ceb59e6-2fa6-4177-a8b8-b6130f45ac3f/lessons/09be9405-95aa-4a89-b800-9b60ccde5476/concepts/45252bd7-50b1-41f0-bed5-cef100501c12)。当然也可以将需要的包放在一个文件中，批量安装 pip install -r requirements.txt ，requeirement.txt文件示例如下：
    
```
beautifulsoup4==4.5.1
bs4==0.0.1
pytz==2016.7
requests==2.11.1
```

## */ 28.在线资源 
有空要看！提升软能力！

# /彩蛋/

大家第1个项目，过了没！爽不爽啊！本周开始我们将会完成初级数据分析中最难搞也最能让你成长的项目了。希望大家能够按照本周导学的内容，先学习完内容，在准备好项目的环境和文件。

其中学习的内容主要是4部分，大家可以每天搞1到2个，这样周六咱们视频讲解的时候，就是复习，而不是第一次听了。本周虽然没有项目提交，但是内容还是比较多的，没有编程经验的同学，一定记得多看、多试、多问，大家一起加油！