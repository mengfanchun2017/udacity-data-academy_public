WITH no1 AS (
SELECT STRFTIME('%Y-%m',o.OrderDate) AS YearMonth, SUM(p.UnitPrice*od.Quantity) AS Raclette
FROM Products p
JOIN OrderDetails od
ON p.ProductID = od.ProductID
JOIN Orders o
ON o.OrderID = od.OrderID
WHERE DATE(o.OrderDate) < STRFTIME('2016-05-01') AND p.ProductName IN ('Raclette Courdavault')
GROUP BY 1
ORDER BY 1),

no2 AS (
SELECT STRFTIME('%Y-%m',o.OrderDate) AS YearMonth, SUM(p.UnitPrice*od.Quantity) AS Camembert
FROM Products p
JOIN OrderDetails od
ON p.ProductID = od.ProductID
JOIN Orders o
ON o.OrderID = od.OrderID
WHERE DATE(o.OrderDate) < STRFTIME('2016-05-01') AND p.ProductName IN ('Camembert Pierrot')
GROUP BY 1
ORDER BY 1),

no3 AS (
SELECT STRFTIME('%Y-%m',o.OrderDate) AS YearMonth, SUM(p.UnitPrice*od.Quantity) AS Tarte
FROM Products p
JOIN OrderDetails od
ON p.ProductID = od.ProductID
JOIN Orders o
ON o.OrderID = od.OrderID
WHERE DATE(o.OrderDate) < STRFTIME('2016-05-01') AND p.ProductName IN ('Tarte au sucre')
GROUP BY 1
ORDER BY 1),

no4 AS (
SELECT STRFTIME('%Y-%m',o.OrderDate) AS YearMonth, SUM(p.UnitPrice*od.Quantity) AS Gnocchi
FROM Products p
JOIN OrderDetails od
ON p.ProductID = od.ProductID
JOIN Orders o
ON o.OrderID = od.OrderID
WHERE DATE(o.OrderDate) < STRFTIME('2016-05-01') AND p.ProductName IN ('Gnocchi di nonna Alice')
GROUP BY 1
ORDER BY 1),

no5 AS (
SELECT STRFTIME('%Y-%m',o.OrderDate) AS YearMonth, SUM(p.UnitPrice*od.Quantity) AS Manjimup
FROM Products p
JOIN OrderDetails od
ON p.ProductID = od.ProductID
JOIN Orders o
ON o.OrderID = od.OrderID
WHERE DATE(o.OrderDate) < STRFTIME('2016-05-01') AND p.ProductName IN ('Manjimup Dried Apples')
GROUP BY 1
ORDER BY 1)

SELECT no1.YearMonth, no1.Raclette, no2.Camembert, no3.Tarte, no4.Gnocchi, no5.Manjimup
FROM no1
LEFT JOIN no2
ON no1.YearMonth = no2.YearMonth
LEFT JOIN no3
ON no1.YearMonth = no3.YearMonth
LEFT JOIN no4
ON no1.YearMonth = no4.YearMonth
LEFT JOIN no5
ON no1.YearMonth = no5.YearMonth
ORDER BY 1