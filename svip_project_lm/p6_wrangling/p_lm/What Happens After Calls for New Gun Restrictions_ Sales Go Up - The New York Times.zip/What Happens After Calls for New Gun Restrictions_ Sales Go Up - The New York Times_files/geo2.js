(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "BEIJING",
      'continent': "AS",
      'country': "CN",
      'region': "BJ"
    },
    'ip':"114.249.133.53"
  }]);
})
//
()

;